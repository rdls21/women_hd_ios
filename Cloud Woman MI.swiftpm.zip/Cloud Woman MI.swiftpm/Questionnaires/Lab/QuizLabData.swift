import Foundation

struct QuizLabData {
    /// Anemia
    var anemia: Bool
    /// Diabetes
    var diabetes: Bool
    /// High Blood Pressure
    var high_blood_pressure: Bool
    /// Serum Creatinine 0.5 ... 10
    var serum_creatinine: Float
    /// Serum Sodium 100 ... 150
    var serum_sodium: Int
    /// Smoking
    var smoking: Bool
    // For Interactor Porpuses
    /// Post String
    // Build the questionnaire
    var postString: String {
        let anemia = anemia ? "Yes" : "No"
        let diabetes = diabetes ? "Yes" : "No"
        let high_blood_pressure = high_blood_pressure ? "Yes" : "No"
        let serum_creatinine = serum_creatinine
        let serum_sodium = serum_sodium
        let smoking = smoking ? "Yes" : "No"
        return "anemia=\(anemia)&diabetes=\(diabetes)&high_blood_pressure=\(high_blood_pressure)&serum_creatinine=\(serum_creatinine)&serum_sodium=\(serum_sodium)&smoking=\(smoking)"
    }
}
extension QuizLabData {
    static let sampleData: QuizLabData = .init(anemia: false, diabetes: false, high_blood_pressure: false, serum_creatinine: 0.5, serum_sodium: 125, smoking: true)
}

