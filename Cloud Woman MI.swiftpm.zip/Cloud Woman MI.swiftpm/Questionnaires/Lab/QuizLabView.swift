import SwiftUI

struct QuizLabView: View {
    let settings: SettingsData
    @ObservedObject var serverStatus: Reach
    @State var questionnaire: QuizLabData
    @State var predictedOutcome: String
    private var status: ReachabilityStatus {
        serverStatus.status
    }
    init(settings: SettingsData, predictedOutcome: String = "Press Calculate") {
        self.settings = settings
        self.serverStatus = .init(urlPath: settings.urlPath)
        self.questionnaire = .sampleData
        self.predictedOutcome = predictedOutcome
    }
    var body: some View {
        Form {
            Section(header: Text("Server Status")) {
                ServerStatusView(status: status)
            }
            Picker(selection: $questionnaire.anemia, label: Text("Anemia")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.diabetes, label: Text("Diabetes")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.high_blood_pressure, label: Text("High Bool Pressure")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            TextField("Serum Creatinine", value: $questionnaire.serum_creatinine, format: .number)
            TextField("Serum Sodium", value: $questionnaire.serum_sodium, format: .number)
            Picker(selection: $questionnaire.smoking, label: Text("Smoking")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Section {
                Text("Result: \(predictedOutcome)")
                    .font(.title)
                Button(action: { calculateRisk() }, label: {
                    Text("Calculate Risk")
                })
            }
        }.refreshable {
            setServerStatus()
        }.onAppear {
            setServerStatus()
        }
        .navigationTitle("Lab Dataset")
    }
    func setServerStatus() {
        Task {
            await serverStatus.connectionStatus()
        }
    }
    func calculateRisk() {
        Task {
            // Server Interactor
            let predicData = CloudWMIData(endpoint: settings.completePath(endpoint: 4))
            // String
            let postString = questionnaire.postString
            if status == .online(.wiFi(.serverReachable)) {
                do {
                    predictedOutcome = try await predicData.fetchResult(postString)
                } catch let e {
                    predictedOutcome = e.localizedDescription
                }
            } else {
                predictedOutcome = "\(14) \(12)"
            }
        }
    }
}

#Preview {
    QuizLabView(settings: .ver_cero)
}
