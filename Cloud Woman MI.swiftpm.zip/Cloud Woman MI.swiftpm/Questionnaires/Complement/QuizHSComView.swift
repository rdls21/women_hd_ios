import SwiftUI

struct QuizHSComView: View {
    let settings: SettingsData
    @ObservedObject var serverStatus: Reach
    @State var questionnaire: QuizDataHSCom
    @State var predictedOutcome: String
    private var status: ReachabilityStatus {
        serverStatus.status
    }
    init(settings: SettingsData, predictedOutcome: String = "Press Calculate") {
        self.settings = settings
        self.serverStatus = .init(urlPath: settings.urlPath)
        self.questionnaire = .sampleData
        self.predictedOutcome = predictedOutcome
    }
    var body: some View {
        Form {
            Section(header: Text("Server Status")) {
                ServerStatusView(status: status)
            }
            DatePicker("Birth Date", selection: $questionnaire.birth_day, displayedComponents: .date)
            Picker(selection: $questionnaire.education, label: Text("Education")) {
                ForEach(Education.allCases, id: \.id) { category in
                    Text(category.rawValue).tag(category.id)
                }
            }
            Picker(selection: $questionnaire.tobacco_addiction, label: Text("Cigarrete Adiction")) {
                Text("No").tag(TobaccoAddiction.no)
                Text("Yes").tag(TobaccoAddiction.yes(q: 0, y: 0))
            }
            Picker(selection: $questionnaire.hypertension, label: Text("Hypertension")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.bp_meds, label: Text("Blood preassure medication")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.had_stroke, label: Text("Ever Had Stroke")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.diabetes, label: Text("Diabetes")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Section {
                Text("Result: \(predictedOutcome)")
                    .font(.title)
                Button(action: { calculateRisk() }, label: {
                    Text("Calculate Risk")
                })
            }
        }.refreshable {
            setServerStatus()
        }.onAppear {
            setServerStatus()
        }
        .navigationTitle("HS Complement")
    }
    func setServerStatus() {
        Task {
            await serverStatus.connectionStatus()
        }
    }
    func calculateRisk() {
        Task {
            // Server Interactor
            let predicData = CloudWMIData(endpoint: settings.completePath(endpoint: 0))
            let postString = questionnaire.postString
            if status == .online(.wiFi(.serverReachable)) {
                do {
                    predictedOutcome = try await predicData.fetchResult(postString)
                } catch let e {
                    predictedOutcome = e.localizedDescription
                }
            } else {
                predictedOutcome = "\(404)"
            }
        }
    }
}

#Preview {
    QuizHSComView(settings: .ver_cero)
}
