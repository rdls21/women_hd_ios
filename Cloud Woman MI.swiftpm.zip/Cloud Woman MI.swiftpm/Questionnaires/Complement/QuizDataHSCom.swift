import Foundation

/* Attributes
 age, education, tobacco_addiction, bp_meds, had_stroke, hypertension, diabetes, bmi
 */
struct QuizDataHSCom {
    var birth_day: Date
    /// Age of the patient
    var age: Int {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year], from: birth_day, to: Date())
        return components.year ?? 0
    }
    /// Education
    var education: Education
    /// Tobbaco Addiction
    var tobacco_addiction: TobaccoAddiction
    /// Medicated high blood preasure
    var bp_meds: Bool
    /// Stroke
    var had_stroke: Bool
    /// Difficulty walking
    var hypertension: Bool
    /// Diabetic
    var diabetes: Bool
    /// Diabetic
    var bmi: Float
    // For Interactor Porpuses
    /// Post String
    // Build the questionnaire
    var postString: String {
        let age = age.description
        let education = education.rawValue
        var tobacco_add = ""
        var cigs_daily = 0
        switch tobacco_addiction {
        case .no:
            tobacco_add = "No"
        case .yes(let q, _):
            tobacco_add = "Yes"
            cigs_daily = q
        }
        let bp_meds = bp_meds ? "Yes" : "No"
        let had_stroke = had_stroke ? "Yes" : "No"
        let hypertension = hypertension ? "Yes" : "No"
        let diabetes = diabetes ? "Yes" : "No"
        let bmi = bmi.formatted(.number.precision(.fractionLength(2)))
        return "age=\(age)&education=\(education)&tobacco_addiction=\(tobacco_add)&cigs_per_day=\(cigs_daily)&bp_meds=\(bp_meds)&had_stroke=\(had_stroke)&hypertension=\(hypertension)&diabetes=\(diabetes)&bmi=\(bmi)"
    }
}
enum Education: String, CaseIterable, Equatable, Hashable {
    case uneducated, primaryschool, graduate, postgraduate
    var id: Self {self}
}
extension QuizDataHSCom {
    static let sampleData: QuizDataHSCom = .init(birth_day: Date(), education: .uneducated, tobacco_addiction: .yes(q: 5, y: 1), bp_meds: false, had_stroke: false, hypertension: false, diabetes: false, bmi: 19.0)
}
