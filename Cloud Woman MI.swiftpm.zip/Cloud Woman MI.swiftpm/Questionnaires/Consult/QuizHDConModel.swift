import Foundation

/* Symptoms Mixed Dataset
 'age', 'angina_type', 'high_fasting_bs', 'exercise_angina', 'resting_st', 'st_slope', ‘resting_ecg'
 angina_type: ASY, ATA, NAP, TA
 */
/// Consult Model
struct QuizHDConModel {
    var birth_day: Date
    /// Age of the patient
    var age: Int {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year], from: birth_day, to: Date())
        return components.year ?? 0
    }
    /// Angina Type
    var angina_type: AnginaType
    /// Hight Fasting Blood Sugar
    var fasting_bs: Bool
    /// Excersice induced angina
    var exercise_angina: Bool
    /// ST depresion measured as a value
    var resting_st: Float
    /// Slope of the peak exercise ST segment
    var st_slope: STSlope
    /// Resting electrocardiogram results
    var resting_ecg: ECGInterpretation
    // For Interactor Porpuses
    /// Post String
    // Build the questionnaire
    var postString: String {
        let age = String(age)
        let angina_type = angina_type.descripton
        let fasting_bs = fasting_bs ? "Yes" : "No"
        let exercise_angina = exercise_angina ? "Yes" : "No"
        let resting_st = resting_st.formatted(.number.precision(.fractionLength(2)))
        let st_slope = st_slope.description
        let resting_ecg = resting_ecg.description
        print(resting_st)
        return "age=\(age)&angina_type=\(angina_type)&high_fasting_bs=\(fasting_bs)&exercise_angina=\(exercise_angina)&resting_st=\(resting_st)&st_slope=\(st_slope)&resting_ecg=\(resting_ecg)"
    }
}
// TA: Typical Angina, ATA: Atypical Angina, NAP: Non-Anginal Pain, ASY: Asymptomatic
enum AnginaType: String, CaseIterable, Equatable, Hashable {
    case asy, nap, ta,  ata
    var descripton: String {
        switch self {
        case .asy:
            "Asymptomatic"
        case .nap:
            "Non-Anginal Pain"
        case .ta:
            "Typical Angina"
        case .ata:
            "Atypical Angina"
        }
    }
}
enum STSlope: CaseIterable, Equatable, Hashable {
    case up, flat, down
    var description: String {
        return self.description.capitalized
    }
}
// Normal: Normal, ST: having ST-T wave abnormality (T wave inversions and/or ST elevation or depression of > 0.05 mV), LVH: showing probable or definite left ventricular hypertrophy by Estes' criteria
enum ECGInterpretation {
    case normal, st, lvh
    var description: String {
        switch self {
        case .normal: "Normal"
        case .st: "ST"
        case .lvh: "LVH"
        }
    }
}
extension QuizHDConModel {
    static let sampleData: QuizHDConModel = .init(birth_day: Date(), angina_type: .asy, fasting_bs: true, exercise_angina: false, resting_st: 0.0, st_slope: .flat, resting_ecg: .normal)
}
