import SwiftUI

struct QuizRowView: View {
    let title: String
    var body: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading) {
                Text(title)
                    .font(.title)
                    .bold()
                    .font(.headline)
            }
            .padding()
            Spacer()
        }
    }
}

#Preview {
    QuizRowView(title: "Example")
}
