import SwiftUI

struct QuizHD22View: View {
    let settings: SettingsData
    @ObservedObject var serverStatus: Reach
    @State var questionnaire: QuizDataHD22
    @State var predictedOutcome: String
    private var status: ReachabilityStatus {
        serverStatus.status
    }
    init(settings: SettingsData, predictedOutcome: String = "Press Calculate") {
        self.settings = settings
        self.serverStatus = .init(urlPath: settings.urlPath)
        self.questionnaire = .sampleData
        self.predictedOutcome = predictedOutcome
    }
    var body: some View {
        Form {
            Section(header: Text("Server Status")) {
                ServerStatusView(status: status)
            }
            DatePicker("Birth Date", selection: $questionnaire.birth_day, displayedComponents: .date)
            Picker(selection: $questionnaire.race_ethnicity, label: Text("Race Ethnicity")) {
                ForEach(RaceCategories.allCases, id: \.self) { category in
                    Text(category.description).tag(category)
                }
            }
            TextField("Height", value: $questionnaire.height, format: .number)
            TextField("Sleep Time", value: $questionnaire.sleep_time, format: .number)
            Picker(selection: $questionnaire.last_checkup, label: Text("Last Checkup")) {
                ForEach(LastCheckup.allCases, id: \.self) { category in
                    Text(category.description).tag(category)
                }
            }
            Picker(selection: $questionnaire.gen_health, label: Text("General Health")) {
                ForEach(GeneralHealth.allCases, id: \.self) { category in
                    Text(category.description).tag(category)
                }
            }
            Picker(selection: $questionnaire.alcohol_drinker, label: Text("Alcohol Drinker")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.removed_teeth, label: Text("Removed Teeth")) {
                ForEach(RemovedTeeth.allCases, id: \.self) { category in
                    Text(category.description).tag(category)
                }
            }
            Picker(selection: $questionnaire.had_angina, label: Text("Had Angina")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.had_stroke, label: Text("Had Stroke")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.skin_cancer, label: Text("Had Skin Cancer")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.kidney_disease, label: Text("Had Kidney Disease")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.diabetes, label: Text("Diabetes")) {
                ForEach(Diabetes.allCases, id: \.self) { category in
                    Text(category.description).tag(category)
                }
            }
            Picker(selection: $questionnaire.hiv_test, label: Text("HIV Test")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.impaired_vision, label: Text("Impaired Vision")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.diff_walking, label: Text("Difficulty Walking")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.smoker_status, label: Text("Smoker Status")) {
                ForEach(SmokerStatus.allCases, id: \.self) { category in
                    Text(category.description).tag(category)
                }
            }
            Picker(selection: $questionnaire.flu_vax, label: Text("Vaccinated against Flu")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.pneumo_vax, label: Text("Vaccinated against Pheumonia")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Section {
                Text("Result: \(predictedOutcome)")
                    .font(.title)
                Button(action: { calculateRisk() }, label: {
                    Text("Calculate Risk")
                })
            }
        }.refreshable {
            setServerStatus()
        }.onAppear {
            setServerStatus()
        }
        .navigationTitle("HD 2022")
    }
    func setServerStatus() {
        Task {
            await serverStatus.connectionStatus()
        }
    }
    func calculateRisk() {
        Task {
            // Server Interactor
            let predicData = CloudWMIData(endpoint: settings.completePath(endpoint: 3))
            // String
            let postString = questionnaire.postString
            if status == .online(.wiFi(.serverReachable)) {
                do {
                    predictedOutcome = try await predicData.fetchResult(postString)
                } catch let e {
                    predictedOutcome = e.localizedDescription
                }
            } else {
                predictedOutcome = "\(14) \(12)"
            }
        }
    }
}

#Preview {
    QuizHD22View(settings: .ver_cero)
}
