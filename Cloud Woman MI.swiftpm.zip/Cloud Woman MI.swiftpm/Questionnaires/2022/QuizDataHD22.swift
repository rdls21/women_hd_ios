import Foundation

/* Symptoms
 'gen_health', 'last_checkup', 'sleep_time', 'removed_teeth', 'had_angina', 'had_stroke', 'asthma', 'had_copd', 'kidney_disease', 'diabetes', 'hard_hearing', 'impaired_vision', 'diff_walking', 'smoker_status', 'age_category', 'height', 'alcohol_drinker', 'flu_vax', 'race_ethnicity'
 */
struct QuizDataHD22 {
    var birth_day: Date
    /// Age of the patient
    var age: Int {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year], from: birth_day, to: Date())
        return components.year ?? 0
    }
    /// Age Category
    var age_category: AgeCategory {
        switch age {
        case 0..<25:    .ettf
        case 25..<30:   .tftn
        case 30..<35:   .hthf
        case 35..<40:   .hfhn
        case 40..<45:   .ftff
        case 45..<50:   .fffn
        case 50..<55:   .cfcf
        case 55..<60:   .cfcn
        case 60..<65:   .stsf
        case 65..<70:   .sfsn
        case 70..<75:   .etef
        case 75..<80:   .efen
        default:        .eodr
        }
    }
    /// Race ethnicity
    var race_ethnicity: RaceCategories
    /// Patient Height 1.0>3.0
    var height: Float
    /// Sleep Time
    var sleep_time: Int
    /// Last Checkup [Past Year, Past 2 years, Past 5 Years, 5 or More]
    var last_checkup: LastCheckup
    /// General health [poor, fair, good, very good, excelent]
    var gen_health: GeneralHealth
    /// Alcohol Drinker
    var alcohol_drinker: Bool
    /// Removed teeth
    var removed_teeth: RemovedTeeth
    /// Had Angina
    var had_angina: Bool
    /// Stroke
    var had_stroke: Bool
    /// Skin Cancer
    var skin_cancer: Bool
    /// Kidney Disease
    var kidney_disease: Bool
    /// Diabetic
    var diabetes: Diabetes
    /// Impaired Vision
    var impaired_vision: Bool
    /// Difficulty walking
    var diff_walking: Bool
    /// Smoker Status
    var smoker_status: SmokerStatus
    /// HIV Test
    var hiv_test: Bool
    /// Flu Vaccination
    var flu_vax: Bool
    /// Pneumo Vaccination
    var pneumo_vax: Bool
    // For Interactor Porpuses
    /// Post String
    // Build the questionnaire
    var postString: String {
        let gen_health = gen_health.description
        let last_checkup = last_checkup.description
        let sleep_time = sleep_time
        let removed_teeth = removed_teeth.description
        let had_angina = had_angina ? "Yes" : "No"
        let had_stroke = had_stroke ? "Yes" : "No"
        let skin_cancer = skin_cancer ? "Yes" : "No"
        let kidney_disease = kidney_disease ? "Yes" : "No"
        let diabetes = diabetes.description
        let impaired_vision = impaired_vision ? "Yes" : "No"
        let diff_walking = diff_walking ? "Yes" : "No"
        let smoker_status = smoker_status.description
        let age_category = age_category.description
        let height = height.formatted(.number.precision(.fractionLength(2)))
        let alcohol_drinker = alcohol_drinker ? "Yes" : "No"
        let hiv_test = hiv_test ? "Yes" : "No"
        let flu_vax = flu_vax ? "Yes" : "No"
        let pneumo_vax = pneumo_vax ? "Yes" : "No"
        let race_ethnicity = race_ethnicity.description
        return "gen_health=\(gen_health)&last_checkup=\(last_checkup)&sleep_time=\(sleep_time)&removed_teeth=\(removed_teeth)&had_angina=\(had_angina)&had_stroke=\(had_stroke)&skin_cancer=\(skin_cancer)&kidney_disease=\(kidney_disease)&diabetes=\(diabetes)&impaired_vision=\(impaired_vision)&diff_walking=\(diff_walking)&smoker_status=\(smoker_status)&age_category=\(age_category)&height=\(height)&alcohol_drinker=\(alcohol_drinker)&hiv_test=\(hiv_test)&flu_vax=\(flu_vax)&pneumo_vax=\(pneumo_vax)&race_ethnicity=\(race_ethnicity)"
    }
}
/*
 Code whether some features are more important than others
 */
enum LastCheckup: CaseIterable {
    case last_year, last_t_years, last_f_years, f_or_more
    var description: String {
        switch self {
        case .last_year: "Within past year"
        case .last_t_years: "Within past 2 years"
        case .last_f_years: "Within past 5 years"
        case .f_or_more: "5 or more years"
        }
    }
}
enum RemovedTeeth: Equatable, CaseIterable {
    case none, one_five, six_more, all
    var description: String {
        switch self {
        case .none: "None"
        case .one_five: "1 to 5"
        case .six_more: "6 or more, but not all"
        case .all: "All"
        }
    }
}
enum SmokerStatus: Equatable, CaseIterable {
    case never, former, current_o, current_d
    var description: String {
        switch self {
        case .never: "Never smoked"
        case .former: "Former smoker"
        case .current_o: "Current smoker - occasionally"
        case .current_d: "Current smoker - daily"
        }
    }
}
enum RaceCategories: String, Equatable, CaseIterable {
    case white, black, other, multiracial, hispanic
    var description: String {
        rawValue.capitalized
    }
}
extension QuizDataHD22 {
    static let sampleData: QuizDataHD22 = .init(birth_day: Date(), race_ethnicity: .hispanic, height: 1.69, sleep_time: 4, last_checkup: .last_year, gen_health: .good, alcohol_drinker: true, removed_teeth: .none, had_angina: true, had_stroke: false, skin_cancer: true, kidney_disease: false, diabetes: .no, impaired_vision: true, diff_walking: true, smoker_status: .never, hiv_test: false, flu_vax: true, pneumo_vax: true)}
