import SwiftUI

struct QuizHD20View: View {
    let settings: SettingsData
    @ObservedObject var serverStatus: Reach
    @State var questionnaire: QuizDataHD20
    @State var predictedOutcome: String
    private var status: ReachabilityStatus {
        serverStatus.status
    }
    init(settings: SettingsData, predictedOutcome: String = "Press Calculate") {
        self.settings = settings
        self.serverStatus = .init(urlPath: settings.urlPath)
        self.questionnaire = .sampleData
        self.predictedOutcome = predictedOutcome
    }
    var body: some View {
        Form {
            Section(header: Text("Server Status")) {
                ServerStatusView(status: status)
            }
            DatePicker("Birth Date", selection: $questionnaire.birth_day, displayedComponents: .date)
            Picker(selection: $questionnaire.tobacco_addiction, label: Text("Cigarrete Adiction")) {
                Text("No").tag(TobaccoAddiction.no)
                Text("Yes").tag(TobaccoAddiction.yes(q: 0, y: 0))
            }
            Picker(selection: $questionnaire.had_stroke, label: Text("Ever Had Stroke")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.diff_walking, label: Text("Difficulty Walking")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.diabetes, label: Text("Diabetic")) {
                ForEach(Diabetes.allCases, id: \.self) { category in
                    Text(category.description).tag(category)
                }
            }
            Picker(selection: $questionnaire.gen_health, label: Text("General Health")) {
                ForEach(GeneralHealth.allCases, id: \.self) { category in
                    Text(category.description).tag(category)
                }
            }
            Picker(selection: $questionnaire.asthma, label: Text("Asthma")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Picker(selection: $questionnaire.kidney_disease, label: Text("Kidney Disease")) {
                Text("No").tag(false)
                Text("Yes").tag(true)
            }
            Section {
                Text("Result: \(predictedOutcome)")
                    .font(.title)
                Button(action: { calculateRisk() }, label: {
                    Text("Calculate Risk")
                })
            }
        }.refreshable {
            setServerStatus()
        }.onAppear {
            setServerStatus()
        }
        .navigationTitle("HD 2020")
    }
    func setServerStatus() {
        Task {
            await serverStatus.connectionStatus()
        }
    }
    func calculateRisk() {
        Task {
            // Server Interactor
            let predicData = CloudWMIData(endpoint: settings.completePath(endpoint: 2))
            // Quiz String
            let postString = questionnaire.postString
            if status == .online(.wiFi(.serverReachable)) {
                do {
                    predictedOutcome = try await predicData.fetchResult(postString)
                } catch let e {
                    predictedOutcome = e.localizedDescription
                }
            } else {
                predictedOutcome = "\(14) \(12)"
            }
        }
    }
}

#Preview {
    QuizHD20View(settings: .ver_cero)
}
