import Foundation

/* Symptoms
 'tobacco_addiction', 'had_stroke', 'diff_walking', 'age_category', 'diabetes', 'gen_health', 'asthma', 'kidney_disease'
*/
struct QuizDataHD20 {
    /// Tobbaco Addiction
    var tobacco_addiction: TobaccoAddiction
    /// Stroke
    var had_stroke: Bool
    /// Difficulty walking
    var diff_walking: Bool
    /// Birth date of the patient
    var birth_day: Date
    /// Age of the patient
    var age: Int {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year], from: birth_day, to: Date())
        return components.year ?? 0
    }
    /// Age Category
    var age_category: AgeCategory {
        switch age {
        case 0..<25:    .ettf
        case 25..<30:   .tftn
        case 30..<35:   .hthf
        case 35..<40:   .hfhn
        case 40..<45:   .ftff
        case 45..<50:   .fffn
        case 50..<55:   .cfcf
        case 55..<60:   .cfcn
        case 60..<65:   .stsf
        case 65..<70:   .sfsn
        case 70..<75:   .etef
        case 75..<80:   .efen
        default:        .eodr
        }
    }
    /// Diabetic
    var diabetes: Diabetes
    /// General health [poor, fair, good, very good, excelent]
    var gen_health: GeneralHealth
    /// Asthma
    var asthma: Bool
    /// Kidney Disease
    var kidney_disease: Bool
    // For Interactor Porpuses
    /// Post String
    // Build the questionnaire
    var postString: String {
        let smoking = tobacco_addiction != .no ? "Yes" : "No"
        let stroke = had_stroke ? "Yes" : "No"
        let diff_walking = diff_walking ? "Yes" : "No"
        let age_category = age_category.description
        let diabetes = diabetes.description
        let gen_health = gen_health.description
        let asthma = asthma ? "Yes" : "No"
        let kidney_disease = kidney_disease ? "Yes" : "No"
        return "smoking=\(smoking)&stroke=\(stroke)&diff_walking=\(diff_walking)&age_category=\(age_category)&diabetes=\(diabetes)&gen_health=\(gen_health)&asthma=\(asthma)&kidney_disease=\(kidney_disease)"
    }
}
/*
 Code whether some features are more important than others
 */

enum GeneralHealth: Hashable, CaseIterable, Codable {
    case poor, fair, good, veryGood, excellent
    var description: String {
        switch self {
        case .poor:
            return "Poor"
        case .fair:
            return "Fair"
        case .good:
            return "Good"
        case .veryGood:
            return "Very good"
        case .excellent:
            return "Excellent"
        }
    }
}

enum TobaccoAddiction: Equatable, Hashable {
    case no
    case yes(q: Int, y: Int)
    var description: String {
        switch self {
        case .no:
            return "No"
        case .yes(let q, let y):
            return "Yes - \(q) for \(y)"
        }
    }
}
enum AgeCategory: String, CaseIterable, Identifiable, Codable {
    case ettf, tftn, hthf, hfhn, ftff, fffn, cfcf, cfcn, stsf, sfsn, etef, efen, eodr
    var id: Self {self}
    var description: String {
        switch self {
        case .ettf: "18-24"
        case .tftn: "25-29"
        case .hthf: "30-34"
        case .hfhn: "35-39"
        case .ftff: "40-44"
        case .fffn: "45-49"
        case .cfcf: "50-54"
        case .cfcn: "55-59"
        case .stsf: "60-64"
        case .sfsn: "65-69"
        case .etef: "70-74"
        case .efen: "75-79"
        case .eodr: "80 or older"
        }
    }
}
enum Diabetes: Hashable, CaseIterable, Codable {
    case no
    case borderline
    case yesPregnancy
    case yes
    
    var description: String {
        switch self {
        case .no:
            return "No"
        case .borderline:
            return "No, borderline diabetes"
        case .yesPregnancy:
            return "Yes (during pregnancy)"
        case .yes:
            return "Yes"
        }
    }
}
extension QuizDataHD20 {
    static let sampleData: QuizDataHD20 = .init(tobacco_addiction: .no, had_stroke: false, diff_walking: false, birth_day: Date(timeIntervalSince1970: TimeInterval(-85556600)), diabetes: .no, gen_health: .good, asthma: false, kidney_disease: false)
}
