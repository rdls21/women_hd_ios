import SwiftUI

struct ContentView: View {
    let settings: SettingsData
    var body: some View {
        List {
            Section("Complement") {
                NavigationLink(destination: { QuizHSComView(settings: settings) }) { 
                    QuizRowView(title: "Heart Stroke")
                }
            }
            Section("Consult") {
                NavigationLink(destination: { QuizHDConView(settings: settings) }) { 
                    QuizRowView(title: "Mixed Dataset")
                }
                NavigationLink(destination: { QuizHD20View(settings: settings) }) { 
                    QuizRowView(title: "HD 2020")
                }
                NavigationLink(destination: { QuizHD22View(settings: settings) }) { 
                    QuizRowView(title: "HD 2022")
                }
            }
            Section("Laboratory") {
                NavigationLink(destination: { QuizLabView(settings: settings) }) { 
                    QuizRowView(title: "Punjab, Pakistan")
                }
            }
        }
        .toolbar {
            ToolbarItem(placement: .primaryAction) { 
                NavigationLink(destination: SettingsView(settings: settings).navigationTitle("Settings")) {
                    Image(systemName: "gearshape.fill")
                }
            }
        }
        .navigationTitle("Questionnaires")
    }
}
