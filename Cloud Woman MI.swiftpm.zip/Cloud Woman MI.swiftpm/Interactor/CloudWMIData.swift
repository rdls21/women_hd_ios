import Foundation

/// Class that interacts with the women MI API
class CloudWMIData: ObservableObject {
    var result: String
    var endpoint: String
    init (result: String = "NON", endpoint: String) {
        self.result = result
        self.endpoint = endpoint
    }
    func resultURLRequest(_ postString: String) -> URLRequest {
        let url=endpoint
        guard let myUrl = URL(string: url) else { fatalError("This is not a valid URL") }
        var request = URLRequest(url: myUrl)
        request.httpMethod = "POST"
        // Request HEADER
        request.httpBody = postString.data(using: String.Encoding.utf8)
        return request
    }
    func fetchResult(_ postString: String) async throws -> String {
        let request = resultURLRequest(postString)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            return "!200"
        }
        self.result = String(data: data, encoding: .utf8) ?? "EMPTY"
        return self.result
    }
}
