import Foundation

class SettingsStore: ObservableObject {
    @Published var settings: SettingsData = .ver_cero
    private static func fileURL() throws -> URL {
        try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("settings.data")
    }    
    static func load(completion: @escaping (Result<SettingsData,Error>)->Void) {
        DispatchQueue.global(qos: .background).async {
            do {
                let fileURL = try fileURL()
                guard let file = try? FileHandle(forReadingFrom: fileURL) else {
                    // Nothing is Written
                    DispatchQueue.main.async {
                        completion(.success(SettingsData.ver_cero))
                    }
                    return
                }
                let settingsData = try JSONDecoder().decode(SettingsData.self, from: file.availableData)
                DispatchQueue.main.async {
                    completion(.success(settingsData))
                }
            } catch {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    static func save(settings: SettingsData, completion: @escaping(Result<Bool, Error>)->Void) {
        do {
            let data = try JSONEncoder().encode(settings)
            let outfile = try fileURL()
            try data.write(to: outfile)
            DispatchQueue.main.async {
                completion(.success(true))
            }
        } catch {
            DispatchQueue.main.async {
                completion(.failure(error))
            }
        }
    }
}
