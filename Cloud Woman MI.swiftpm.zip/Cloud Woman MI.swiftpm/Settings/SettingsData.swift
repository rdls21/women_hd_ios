import Foundation


struct SettingsData: Codable {
    /// The saved URL path of the endpoint
    var urlPath: String
    var endpoints: [Int : String]
    public func completePath(endpoint: Int) -> String {
        // Create a safe variable
        let hBool = endpoints.keys.contains(endpoint)
        let selEnd = hBool ? endpoint : 1
        let finalPath = urlPath.appending(endpoints[selEnd]!)
        return finalPath
    }
}
// Updating logic
extension SettingsData {
    struct Data {
        var urlPath = ""
        var endpoints = [0 : ""]
    }
    var data: Data {
        // Use the Strunct value of path
        Data(urlPath: urlPath)
    }
    mutating func update(from data: Data) {
        urlPath = data.urlPath
    }
    // We pass data object to init the struct
    init(data: Data) {
        urlPath = data.urlPath
        endpoints = data.endpoints
    }
}
extension SettingsData {
    static let ver_cero: SettingsData = SettingsData(urlPath: "https://s6tjrst5-3000.usw3.devtunnels.ms", endpoints: [0: "/whs_com/api", 1: "/whd_con/api", 2: "/hd2020/api", 3: "/hd2022/api", 4: "/whd_lab/api"])
}
