import SwiftUI

struct SettingsView: View {
    let settings: SettingsData
    @ObservedObject var serverStatus: Reach
    private var status: ReachabilityStatus {
        serverStatus.status
    }
    init(settings: SettingsData) {
        self.settings = settings
        self.serverStatus = .init(urlPath: settings.urlPath)
    }
    var body: some View {
        List {
            Section("Server Status") { 
                ServerStatusView(status: status)
            }
            Section("Server Settings") {
                HStack {
                    Text(settings.urlPath)
                }
            }
        }
        .refreshable {
            setServerStatus()
        }.onAppear {
            setServerStatus()
        }
    }
    func setServerStatus() {
        Task {
            await serverStatus.connectionStatus()
        }
    }
}

#Preview {
    SettingsView(settings: .ver_cero)
}
