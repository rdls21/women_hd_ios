import Foundation
import SystemConfiguration

let ReachabilityStatusChangedNotification = "ReachabilityStatusChangedNotification"

enum serverStatus: CustomStringConvertible {
    case serverReachable
    case serverUnavailable
    var description: String {
        switch self {
        case .serverReachable: return "Server Reachable"
        case .serverUnavailable: return "Server Unavailable"
        }
    }
}
enum ReachabilityType: CustomStringConvertible, Equatable {
    case wwan(serverStatus)
    case wiFi(serverStatus)
    var description: String {
        switch self {
        case .wwan(let type): return "WWAN (\(type))"
        case .wiFi(let type): return "WiFi (\(type))"
        }
    }
}
enum ReachabilityStatus: CustomStringConvertible, Equatable {
    case connecting
    case offline
    case online(ReachabilityType)
    case unknown
    var description: String {
        switch self {
        case .connecting: return "Connecting"
        case .offline: return "Offline"
        case .online(let type): return "Online \(type)"
        case .unknown: return "Unknown"
        }
    }
}
public class Reach: ObservableObject {
    @Published var canOpen: Bool = false
    @Published var status: ReachabilityStatus = .unknown
    @Published var urlPath: String
    init(urlPath: String) {
        self.urlPath = urlPath
    }
    func connectionStatus() async {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        zeroAddress.sin_family = sa_family_t(AF_INET)
        guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                SCNetworkReachabilityCreateWithAddress(nil, $0)
            }
        }) else {
            status = .unknown
            return
        }
        var flags : SCNetworkReachabilityFlags = []
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) {
            status = .unknown
        }
        let isServerReachable = await isServerReachable(urlPath: urlPath)
        status = ReachabilityStatus(reachabilityFlags: flags, serverStatus: isServerReachable)
    }
    func isServerReachable(urlPath: String) async -> Bool {
        guard let myUrl = URL(string: urlPath) else {
            fatalError("No es una URL valida")
        }
        var request = URLRequest(url: myUrl)
        request.httpMethod = "GET"
        request.timeoutInterval = 1000
        //URLCache.shared.removeAllCachedResponses()
        status = .connecting
        do {
            let (data , response) = try await URLSession.shared.data(for: request)
            guard let statusCode = ((response) as? HTTPURLResponse)?.statusCode else {
                return false
            }
            if !data.isEmpty {
                canOpen = true
            }
            if statusCode == 200 {
                canOpen = true
            }
        } catch {
            canOpen = false
        }
        return canOpen
    }
}
extension ReachabilityStatus {
    init(reachabilityFlags flags: SCNetworkReachabilityFlags, serverStatus: Bool) {
        let connectionRequired = flags.contains(.connectionRequired)
        let isReachable = flags.contains(.reachable)
        let isWWAN = flags.contains(.isWWAN)
        if !connectionRequired && isReachable {
            if isWWAN {
                self = .online(.wwan(serverStatus ? .serverReachable : .serverUnavailable))
            } else {
                self = .online(.wiFi(serverStatus ? .serverReachable : .serverUnavailable))
            }
        } else {
            self =  .offline
        }
    }
}
