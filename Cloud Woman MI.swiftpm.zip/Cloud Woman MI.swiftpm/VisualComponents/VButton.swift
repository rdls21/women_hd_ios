import SwiftUI

struct VButton: View {
    let label: String
    let systemImage: String
    let action: ()->Void
    var body: some View {
        Button(action: { action() }, label: {
            VStack {
                Image(systemName: systemImage)
                    .font(.title)
                Text(label)
            }
            .frame(width: 100, alignment: .center)
        })
        .buttonStyle(.bordered)
    }
}

#Preview {
    VButton(label: "Update Medical ID", systemImage: "pencil.and.ruler", action: {})
}
