import SwiftUI

struct WallpaperView: View {
    var image: Image
    var body: some View {
        image
            .resizable()
            .aspectRatio(1.6, contentMode: .fit)
            .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

#Preview {
    WallpaperView(image: Image("profile_wallpaper0"))
}
