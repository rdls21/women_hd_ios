import SwiftUI

struct ServerStatusView: View {
    let status: ReachabilityStatus
    var body: some View {
        switch status {
        case .connecting:
            Label("Connecting", systemImage: "wifi")
                .symbolEffect(.variableColor.iterative.reversing)
                .foregroundStyle(.yellow)
                .font(.headline)
        case .offline:
            Label("Not connected", systemImage: "wifi.slash")
                .foregroundStyle(.primary, .gray)
                .font(.headline)
        case .unknown:
            Label("Unknown", systemImage: "exclamationmark.icloud.fill")
                .foregroundStyle(.primary, .gray)
                .font(.headline)
        case .online(.wwan(.serverUnavailable)), .online(.wiFi(.serverUnavailable)):
            Label("Unable to reach", systemImage: "icloud.slash.fill")
                .foregroundStyle(.primary, .red)
                .font(.headline)
        case .online(.wwan(.serverReachable)), .online(.wiFi(.serverReachable)):
            Label("Conected", systemImage: "icloud.fill")
                .foregroundStyle(.green)
                .font(.headline)
        }
    }
}

#Preview {
    List {
        ServerStatusView(status: .unknown)
        ServerStatusView(status: .offline)
        ServerStatusView(status: .connecting)
        ServerStatusView(status: .online(.wiFi(.serverUnavailable)))
        ServerStatusView(status: .online(.wiFi(.serverReachable)))
    }
}
