import SwiftUI

struct ImageView: View {
    var image: Image
    var body: some View {
        image
            .resizable()
            .aspectRatio(1, contentMode: .fit)
            .frame(maxWidth: 202, maxHeight: 202)
            .clipShape(Circle())
            .shadow(radius: 4)
    }
}

#Preview {
    ImageView(image: Image("profile_pic"))
}
